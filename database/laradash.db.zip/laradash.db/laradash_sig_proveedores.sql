-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: laradash
-- ------------------------------------------------------
-- Server version	5.7.38-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sig_proveedores`
--

DROP TABLE IF EXISTS `sig_proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sig_proveedores` (
  `id_proveedor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_proveedor` varchar(45) DEFAULT NULL,
  `id_pais` int(11) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `telefono` varchar(45) DEFAULT NULL,
  `nombre_contacto` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_proveedor`),
  KEY `proveedor_paises_idx` (`id_pais`),
  CONSTRAINT `proveedor_paises` FOREIGN KEY (`id_pais`) REFERENCES `sig_paises` (`id_pais`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sig_proveedores`
--

LOCK TABLES `sig_proveedores` WRITE;
/*!40000 ALTER TABLE `sig_proveedores` DISABLE KEYS */;
INSERT INTO `sig_proveedores` VALUES (1,'Multiline S.A de C.V',1,'Belice','(508) 45787815','Nora Jhones'),(2,'Expecove S.A',3,'Calle La Mascota 210','(503) 2222-1084','Vladimir Rivas'),(3,'Refrihogar',6,'F.M, Avenida Gutemberg, Tegucigalpa, Honduras local 404','(504) 7123-1234','Alexander Acevedo'),(4,'Almacenes Electro',7,'800 metros Oeste de Multiplaza, 10203 San José-Escazú','(506) 7234-9921','Jeremmy Cruz'),(5,'Filadelfia Venta de electrodomésticos',5,'De la caimana 3c al lago o de Punto 99 1c al este, Managua, Nicaragua','(505) 7125-0071','Jennfer Aguilar'),(6,'Almacenes TROPIGAS',1,'6A Avenida 15-36, Cdad. de Guatemala, Guatemala','(501) 7340-0007','Gerard Romero'),(7,'Omnisport',3,'1a Calle Pte, San Salvador','(503) 7420-1321','Juan Carlos Marinez'),(8,'Banjolux',7,'Vía Interamericana, Plaza Bayside d, Panamá-Coronado','(507) 1284-9832','Josué Quintanilla'),(9,'Almacenes Boyacá',7,'Av. Remigio Crespo y calle Esmeraldas. / Cuenca','(507) 9984-1232','Álvaro Menéndez'),(10,'Unique Living',1,'Bay Gardens Hodges Bay Main Road Saint Johns','(501) 3383-1672','Miranda Martínez'),(11,'Distribuidora Los Ángeles',3,'Soyapango, San Salvador','(503) 7283-9878','Pedro Pérez'),(12,'Cerulli S.A',5,'Calle 15 de Septiembre, Managua','(505) 7299-2691','Isaac Ortega'),(13,'Tiendas Ivonne-Linea Blanca',6,'8 y 9 calle 2 avenida barrio concepción, San Pedro Sula 00504, Honduras','(504) 9842-3235','Celeste Rosales'),(14,'Electronica Japonesa ',7,'207, San José Province, Desamparados Local #456, Costa Rica ','(506) 7869-1425','Nely Gonzalez'),(15,'Venta de Electromesticos Solís',5,'Semafaros villa rafaela herrera 75vrs al sur mano izquierda, 11154, Nicaragua','(505) 7078-0102','Ousman Ruiz'),(16,'Bodegangas',1,'Calz. San Juan 27-18, Cdad. de Guatemala, Guatemala Local A-125','(501) 7140-1307','Will Deep'),(17,'Almacenes Prado Onceava etapa',3,'San Salvador Calle Prudencia #800 pol. D','(503) 7610-9685','Genaro Lemus'),(18,'MEGATK',5,'Managua 14026, Nicaragua #1023','(505) 2270-1696','Fernando Hernandez'),(19,'SERVIDOMESTICOS',1,'Bodega No. 20, Ofibodegas Los Almendros, 2da. Av 13-35, Cdad. de Guatemala 01017, Guatemala','(501) 2251-8927','Juan Mendez'),(20,'Island',3,'San Salvador Calle Las perlitas #242','(503) 2271-0917','Kevin Diaz'),(21,'Megahogar',3,'San Salvador Local #23, San Salvador','(503) 2260-8331','Gerardo Garcia');
/*!40000 ALTER TABLE `sig_proveedores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-13  8:57:07

-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: laradash
-- ------------------------------------------------------
-- Server version	5.7.38-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sig_vendedores`
--

DROP TABLE IF EXISTS `sig_vendedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sig_vendedores` (
  `id_vendedor` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_vendedor` varchar(45) DEFAULT NULL,
  `nombre_vendedor` varchar(100) DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `id_sucursal` int(11) DEFAULT NULL,
  `numero_documento` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_vendedor`),
  KEY `vendor_sucursales_idx` (`id_sucursal`),
  CONSTRAINT `vendor_sucursales` FOREIGN KEY (`id_sucursal`) REFERENCES `sig_sucursales` (`id_sucursal`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sig_vendedores`
--

LOCK TABLES `sig_vendedores` WRITE;
/*!40000 ALTER TABLE `sig_vendedores` DISABLE KEYS */;
INSERT INTO `sig_vendedores` VALUES (1,'zj5531-80','Brionna Kerluke','2020-08-30',5,'09265292-4'),(2,'ad0254-99','Haskell Predovic','2017-01-29',2,'02023698-3'),(3,'ff8174-07','Jeanette Kutch V','2014-07-10',2,'03328216-3'),(4,'lq5695-78','Sandrine Corkery','2012-06-12',7,'04599100-0'),(5,'oz2632-25','Jayden Conn','2013-07-27',8,'08225746-4'),(6,'sb5801-51','Prof. Seamus Hansen','2015-03-07',5,'02218894-4'),(7,'dt5863-50','Webster Crona','2021-09-18',8,'07316995-2'),(8,'zd0598-63','Prof. Lee Ebert MD','2020-06-28',12,'01207076-4'),(9,'mq6783-18','Marcelino Langosh','2016-02-05',11,'04491751-8'),(10,'sm0006-73','Ahmad Strosin','2020-09-24',6,'06185121-4'),(11,'sw8782-60','Lindsey Witting','2016-10-07',1,'06018886-0'),(12,'wk3771-33','Dortha Schoen','2016-09-18',6,'03794089-0'),(13,'sd5237-25','Constantin Bins','2017-10-02',14,'05095226-8'),(14,'mz0597-90','Alisa Rath','2014-05-10',10,'08154127-5'),(15,'rd6781-88','Kenyatta Goldner','2014-09-25',9,'03921726-6'),(16,'dy8693-79','Gabe Waters','2021-06-25',3,'09166926-9'),(17,'ne4074-03','Evelyn Carroll','2022-04-19',1,'05388349-6'),(18,'zg7553-55','Orpha Nader','2017-01-29',13,'06779934-0'),(19,'gp7559-96','Dedric Goldner','2018-04-05',2,'03798938-0'),(20,'vp4545-13','Kale Smitham','2013-07-11',12,'06226098-5'),(21,'xt7360-66','Hester Hagenes','2017-08-26',9,'07074351-9'),(22,'vd1774-69','Hazel Kiehn PhD','2019-04-02',11,'08217235-4'),(23,'rg8266-59','Sim Howell','2016-01-12',3,'07439763-4'),(24,'bd8087-32','Damion Howell Jr.','2021-04-02',9,'01818437-7'),(25,'jq8037-87','Colby Pouros','2021-10-24',7,'00929241-9'),(26,'dd4090-78','Prof. Johnson Hammes','2019-07-31',7,'03962245-6'),(27,'vu3053-70','Damian Schumm','2021-07-11',9,'05631618-2'),(28,'ku9329-83','Rasheed Sipes V','2018-08-17',8,'09443561-4'),(29,'cv3142-20','Prof. Cheyenne Kuhn','2020-10-06',6,'06766827-1'),(30,'wd4374-89','Alessandro Hand','2014-07-21',7,'05735424-4'),(31,'wg5047-10','Maymie Dickinson','2020-12-26',7,'09107063-1'),(32,'ej0589-69','Mrs. Arlene McDermott MD','2019-09-04',11,'02716625-5'),(33,'ab0883-93','Noemie Kling','2020-11-20',8,'02055069-7'),(34,'rn7180-15','Leanna Gulgowski','2020-10-09',9,'07907132-2'),(35,'ha3663-30','Misael Thiel Sr.','2021-09-28',3,'02844473-8'),(36,'qv6581-48','Tracey Hirthe Sr.','2013-05-12',2,'02890465-5'),(37,'vh0100-59','Seth Heidenreich','2019-04-09',13,'08672289-8'),(38,'fe2515-74','Carlie Blick','2016-05-13',11,'07696483-2'),(39,'oc2344-86','Prof. Guy Schultz MD','2017-06-13',13,'05857813-5'),(40,'as9602-27','Reynold Muller','2013-11-12',9,'03189224-1'),(41,'jj9654-87','Mr. Lester Rutherford I','2016-07-02',3,'08179097-7'),(42,'bl9253-93','Prof. Chadrick Maggio IV','2017-09-09',14,'04144228-5'),(43,'rx5561-40','Carmel Bashirian','2019-06-25',14,'07364704-9'),(44,'if8145-24','Antwan Kreiger','2015-11-10',2,'08147988-2'),(45,'dw6385-75','Katrina Mertz III','2022-06-04',10,'02696459-8'),(46,'wq2602-30','Dr. Tatyana Greenholt Jr.','2014-09-06',9,'02741086-7'),(47,'fi9101-99','Cedrick Bosco','2020-10-21',4,'04387018-5'),(48,'ow7642-37','Ms. Pascale Koepp DDS','2019-06-03',11,'08910806-7'),(49,'lm4327-25','Rosendo Fahey','2022-02-05',8,'08842438-8'),(50,'re2977-00','Mrs. Clementine Schinner','2017-12-20',6,'07253538-3'),(51,'nq9682-03','Kamille Kulas','2017-09-17',8,'00178569-2'),(52,'pa9488-80','Mrs. Molly Rutherford MD','2019-06-08',2,'07613760-1'),(53,'fs7743-28','Tony Wehner','2021-09-21',2,'01821083-6'),(54,'ha9868-61','Ewell Ward','2020-08-05',11,'07029477-3'),(55,'vn9896-31','Amya Conn','2014-03-15',11,'06505853-0'),(56,'rz7895-64','Mrs. Mona Schneider','2014-11-25',9,'09225737-6'),(57,'gd9624-10','Everette Koch','2015-09-21',4,'06823380-5'),(58,'dg6900-58','Mr. Will Bailey','2017-09-12',5,'06959642-0'),(59,'nq6369-13','Ms. Abigale Kassulke MD','2022-03-03',3,'08013840-8'),(60,'gf7128-69','Mrs. Elyssa Barton','2020-01-20',9,'06582017-3'),(61,'ng5978-31','Deanna Grant','2012-09-21',11,'02573427-8'),(62,'nl4208-92','Jayne Sauer','2013-12-19',9,'04960249-2'),(63,'ft7685-08','Lorine Wilkinson','2019-11-11',6,'03088851-8'),(64,'at1906-88','Prof. Gracie Schinner MD','2015-07-29',5,'02529577-6'),(65,'pd6105-49','Pearlie McGlynn','2013-08-10',3,'05095718-3'),(66,'tl2965-67','Zella Sanford','2014-10-15',8,'01640213-3'),(67,'ip3358-35','Dr. Keon Stark','2012-09-05',6,'09355809-8'),(68,'eq9917-06','Chadrick Rath MD','2015-10-08',2,'00367228-3'),(69,'ej2652-00','Mrs. Eldridge Kuphal','2020-04-06',5,'06445071-3'),(70,'pe8461-24','Brandi Erdman','2020-10-13',4,'05835543-6'),(71,'yg6533-88','Miss Adela Steuber','2019-08-09',10,'09503017-2'),(72,'xw3382-15','Johan Kutch','2013-07-01',7,'03208172-0'),(73,'uc3930-43','Dr. Caesar Smith V','2020-08-17',4,'07735189-3'),(74,'pl3387-96','Arturo Collier','2019-12-11',10,'00114762-1'),(75,'db6337-75','Sid Kessler','2016-07-20',8,'01228698-9'),(76,'wq2174-06','Amos Friesen I','2015-08-19',13,'01362972-1'),(77,'cm3521-56','Elroy Howe','2016-04-28',4,'05943398-7'),(78,'hm0651-18','Dr. Paula Denesik Jr.','2013-06-20',12,'01974115-4'),(79,'km7708-07','Mr. Jeremie Spencer Sr.','2022-02-22',9,'05544418-4'),(80,'hs8744-35','Amparo Yost','2020-06-11',12,'03530579-4'),(81,'se6068-29','Marcus Crooks','2020-03-07',4,'02364635-3'),(82,'kk5379-69','Patsy Kozey','2016-03-30',2,'06860252-1'),(83,'eu2096-51','Devin Kunze I','2013-04-14',13,'08628162-1'),(84,'ku2742-43','Odell Klocko','2012-10-07',6,'07997501-7'),(85,'tu2716-07','Peggie Hand','2021-06-27',12,'00391284-5'),(86,'lb5137-19','Kamryn Schinner','2014-10-15',9,'09191058-3'),(87,'zm4285-80','Mr. Lon Pfeffer','2019-06-24',1,'00798432-5'),(88,'jf8823-59','Sigmund Bruen','2019-01-02',1,'08619221-4'),(89,'ty7036-58','Mr. Dayne Reichert','2019-11-08',13,'00778520-2'),(90,'du9939-46','Novella Halvorson','2015-01-19',3,'02309783-7'),(91,'ok2331-87','Trycia Reinger','2019-07-06',10,'06846110-2'),(92,'hz8335-15','Maci Schmidt','2013-04-15',10,'05492310-6'),(93,'at1334-64','Cielo Wisozk','2016-04-26',11,'07747906-6'),(94,'mb1630-21','Amiya Heidenreich','2013-10-01',1,'05524702-2'),(95,'tu2552-02','Dr. Barney Lubowitz','2019-07-15',14,'08814735-0'),(96,'cz4263-26','Darien Treutel IV','2022-05-02',14,'05477838-8'),(97,'ul5513-24','Tatum Koepp','2017-02-06',9,'00803777-5'),(98,'hi8189-01','Mrs. Joannie Von','2015-05-18',5,'07522242-8'),(99,'au9371-68','Thalia Bartoletti','2016-11-02',1,'02561298-4'),(100,'fz3203-00','Miss Brenna Pfeffer','2015-07-22',13,'03497412-3');
/*!40000 ALTER TABLE `sig_vendedores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-13  8:57:07

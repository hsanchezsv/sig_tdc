-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: laradash
-- ------------------------------------------------------
-- Server version	5.7.38-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sig_productos`
--

DROP TABLE IF EXISTS `sig_productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sig_productos` (
  `id_producto` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_producto` varchar(45) DEFAULT NULL,
  `nombre_producto` varchar(45) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `id_pais` int(11) DEFAULT NULL,
  `precio_unidad` decimal(10,0) DEFAULT NULL,
  `fecha_compra` varchar(30) DEFAULT NULL,
  `fecha_vencimiento` varchar(30) DEFAULT NULL,
  `lote_numero` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_producto`),
  KEY `pais_productos_idx` (`id_pais`),
  KEY `proveedor_productos_idx` (`id_proveedor`),
  CONSTRAINT `pais_productos` FOREIGN KEY (`id_pais`) REFERENCES `sig_paises` (`id_pais`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `proveedor_productos` FOREIGN KEY (`id_proveedor`) REFERENCES `sig_proveedores` (`id_proveedor`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sig_productos`
--

LOCK TABLES `sig_productos` WRITE;
/*!40000 ALTER TABLE `sig_productos` DISABLE KEYS */;
INSERT INTO `sig_productos` VALUES (1,'SC-1259','Secadora de Pelo SMART-HAIR',1,6,35,'02/FEB/2021','02/FEB/2023','12398'),(2,'TV-00660','TV Samsung Smart 60pulg',21,3,524,'25/JUN/2021','25/JUN/2022','00839'),(3,'CV-01342','Camara de video LENOVO',20,3,95,'11/DIC/2021','11/DIC/2023','00302'),(4,'ES-9934','Equipo de sonido Samsung',19,1,351,'12/MAR/2021','12/MAR/2023','09800'),(5,'ES-T4890','Teatro en casa Sony',18,5,453,'22/ABR/2021','22/ABR/2023','02398'),(6,'SY-P500','Sony Play Station 5',17,3,750,'02/NOV/2021',NULL,'11098'),(7,'SY-P400','Sony Play Station 4',16,1,400,'25/FEB/2021',NULL,'19884'),(8,'LV-L001','Lavadora Cetron',15,5,822,'12/ABR/2021','12/ABR/2023','00645'),(9,'HM-M3490','Horno microondas Mabe',14,7,78,'31/AGO/2021','31/AGO/2022','00456'),(10,'IM-I8903','Impresora Cannon CA-100',13,6,194,'02/SEP/2021','02/SEP/2023','01398'),(11,'FX-F0589','Fax EPSON EP-500',5,5,351,'25/FEB/2021','25/FEB/2023','00945'),(12,'TV-0860','TV LG Smart 60pulg',7,3,521,'30/ENE/2021','30/ENE/2022','00938'),(13,'TV-0870','TV LG Smart 70pulg',7,3,721,'30/ENE/2021','30/ENE/2022','00941'),(14,'XB-0050','XBOX Series S',12,5,500,'30/NOV/2021',NULL,'15879'),(15,'XB-0060','XBOX Series X',12,5,800,'30/NOV/2021',NULL,'16079'),(16,'SP-0589','Apple iPhone 13',17,3,1211,'09/DIC/2021','09/DIC/2022','11945'),(17,'SP-0104','Samsung Galaxy S21',1,6,1151,'11/DIC/2021','11/DIC/2023','10339'),(18,'SW-0332','Huawei SmartWatch 2GT',2,3,251,'25/FEB/2021','25/FEB/2023','00945'),(19,'CE-112','Cocina Electrica Mabe',3,6,551,'01/AGO/2021','01/AGO/2023','00712'),(20,'VE-F0589','Ventilador de Torre Mastertech',4,7,40,'17/SEP/2021','17/SEP/2022','009613'),(21,'PR-1189','Plancha de ropa Omega',20,3,51,'09/DIC/2021','09/DIC/2022','08945'),(22,'SP-0104','Samsung Galaxy Tab A',21,3,350,'11/DIC/2021','11/DIC/2023','10339'),(23,'SW-0333','Huawei SmartWatch GT Pro',18,5,451,'28/ABR/2021','28/ABR/2023','01645'),(24,'PR-102','Pilas recargables Duracell',16,1,12,'01/ENE/2022','01/ENE/2023','09912'),(25,'MC-0175','Monitor Asus QR249',17,3,250,'17/SEP/2021','17/SEP/2022','007613'),(26,'AU-1280','Audifonos Sony',17,3,70,'14/DIC/2021','14/DIC/2022','01185'),(27,'BC-0104','Bocinas Xiaomi',7,3,151,'11/DIC/2021','11/DIC/2023','06339'),(28,'CM-0333','Control Xbox Series',19,1,80,'28/NOV/2021',NULL,'16645'),(29,'CM-0334','Control PlayStation',19,1,80,'28/NOV/2022',NULL,'17012'),(30,'FC-0175','Focos Led 60W',10,1,10,'17/SEP/2021',NULL,'019122');
/*!40000 ALTER TABLE `sig_productos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-13  8:57:07
